//
//  Constants.swift
//  WebService
//
//  Created by Bubna K on 26/6/22.
//

import Foundation

let baseUrl = "http://www.omdbapi.com/"
